# food > 2023-06-14 8:25am
https://universe.roboflow.com/capstone-ldqkf/food-h4wpj

Provided by a Roboflow user
License: CC BY 4.0

